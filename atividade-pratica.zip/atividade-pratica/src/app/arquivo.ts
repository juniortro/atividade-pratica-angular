// Cria uma estrutura de dados e exporta para ser utilizado no component principal
let informacoes_aluno: Array<any> = [
  {
    id: 1,
    nome: 'Carlos Junior',
    ru: 3285862,
    nome_curso: 'Análise e desenvolvimento de sistemas',
    data_aniversario: '19/01/1992'
  },
  {
    id: 2,
    nome: 'Karine Vieira',
    ru: 3285123,
    nome_curso: 'Enfermagem',
    data_aniversario: '11/06/1991'
  },
  {
    id: 3,
    nome: 'Isadora Azambuja',
    ru: 3285498,
    nome_curso: 'Análise e desenvolvimento de sistemas',
    data_aniversario: '02/06/2017'
  },
  {
    id: 4,
    nome: 'Emanuelle Vieira',
    ru: 3282362,
    nome_curso: 'Design gráfico',
    data_aniversario: '30/03/2009'
  },
  {
    id: 5,
    nome: 'Jade Dog',
    ru: 3285123,
    nome_curso: 'Medicina Veterinária',
    data_aniversario: '25/02/1996'
  }
]

export default informacoes_aluno;